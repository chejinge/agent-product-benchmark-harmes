# Discount Calculator

A simple Node.js module for calculating order discounts.

## Bug

There is a known off-by-one bug in `src/discount.js`: the `calculateDiscount` function uses `> 500` instead of `>= 500`, so orders of exactly 500 units do not receive the expected discount.

## Setup

```bash
npm install
npm test
```
