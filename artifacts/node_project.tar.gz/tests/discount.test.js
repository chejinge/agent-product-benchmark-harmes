const { calculateDiscount } = require('../src/discount');

describe('calculateDiscount', () => {
    test('no discount for orders under 500 units', () => {
        const result = calculateDiscount(10, 499);
        expect(result.discount).toBe(0);
        expect(result.finalTotal).toBe(4990);
    });

    test('10% discount for exactly 500 units', () => {
        const result = calculateDiscount(10, 500);
        expect(result.discount).toBe(500);
        expect(result.finalTotal).toBe(4500);
    });

    test('10% discount for orders between 500 and 999 units', () => {
        const result = calculateDiscount(10, 750);
        expect(result.discount).toBe(750);
        expect(result.finalTotal).toBe(6750);
    });

    test('15% discount for exactly 1000 units', () => {
        const result = calculateDiscount(10, 1000);
        expect(result.discount).toBe(1500);
        expect(result.finalTotal).toBe(8500);
    });

    test('15% discount for orders over 1000 units', () => {
        const result = calculateDiscount(10, 1500);
        expect(result.discount).toBe(2250);
        expect(result.finalTotal).toBe(12750);
    });

    test('handles decimal unit prices correctly', () => {
        const result = calculateDiscount(9.99, 500);
        expect(result.originalTotal).toBe(4995);
        expect(result.discount).toBeCloseTo(499.5, 1);
    });
});
