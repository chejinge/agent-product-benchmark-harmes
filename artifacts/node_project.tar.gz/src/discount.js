/**
 * Calculate the discount for an order based on quantity.
 *
 * Pricing rules:
 * - Orders of 500 units or more get a 10% discount
 * - Orders of 1000 units or more get a 15% discount
 * - All other orders get no discount
 *
 * @param {number} unitPrice - Price per unit
 * @param {number} quantity - Number of units ordered
 * @returns {{ originalTotal: number, discount: number, finalTotal: number }}
 */
function calculateDiscount(unitPrice, quantity) {
    const originalTotal = unitPrice * quantity;
    let discountRate = 0;

    // BUG: should be >= 500, not > 500
    if (quantity > 1000) {
        discountRate = 0.15;
    } else if (quantity > 500) {
        discountRate = 0.10;
    }

    const discount = originalTotal * discountRate;
    const finalTotal = originalTotal - discount;

    return {
        originalTotal: Math.round(originalTotal * 100) / 100,
        discount: Math.round(discount * 100) / 100,
        finalTotal: Math.round(finalTotal * 100) / 100
    };
}

module.exports = { calculateDiscount };
